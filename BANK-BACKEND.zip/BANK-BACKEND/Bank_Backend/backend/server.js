const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const mongoose = require('mongoose');
const jwt = require('jsonwebtoken');
const app = express();
const port = 3000;
const bcrypt = require('bcrypt');



const SECRET_KEY = 'your_secret_key'; // Replace with your own secret key

// Middleware
app.use(bodyParser.json());
app.use(cors());

// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/Chilaka', { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => console.log('MongoDB connected...'))
    .catch(err => console.log(err));

// Define User schema and model
const userSchema = new mongoose.Schema({
    username: String,
    password: String,
    email: String
});

const User = mongoose.model('User', userSchema);

// Define Account schema and model
const accountSchema = new mongoose.Schema({
    userId: mongoose.Schema.Types.ObjectId,
    username: String,
    accountNumber: String,
    balance: Number
});

const Account = mongoose.model('Account', accountSchema);

// Middleware to verify JWT
const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];
    if (!token) return res.status(401).json({ message: 'Access denied' });

    jwt.verify(token, SECRET_KEY, (err, user) => {
        if (err) return res.status(403).json({ message: 'Invalid token' });
        req.user = user;
        next();
    });
};

// Signup endpoint
app.post('/signup', async (req, res) => {
    const { username, password, email } = req.body;

    // Basic validation
    if (!username || !password || !email) {
        return res.status(400).json({ message: 'All fields are required' });
    }

    // Check if user already exists
    const userExists = await User.findOne({ email });
    if (userExists) {
        return res.status(400).json({ message: 'User already exists' });
    }

    // Hash the password
   const hashedPassword =password;

    // Store user
    const newUser = new User({ username, password: hashedPassword, email });
    await newUser.save();
    res.status(200).json({ message: 'User registered successfully' });
});

// Login endpoint
app.post('/login', async (req, res) => {
    const { email, password } = req.body;

    // Basic validation
    if (!email || !password) {
        return res.status(400).json({ message: 'All fields are required' });
    }

    // Check if user exists and password matches
    const user = await User.findOne({ email, password });
    if (!user) {
        return res.status(400).json({ message: 'Invalid email or password' });
    }

    // Generate JWT
    const token = jwt.sign({ id: user._id, email: user.email, username: user.username,password:user.password }, SECRET_KEY, { expiresIn: '1h' });
    res.status(200).json({ message: 'Login successful', token });
});

// Create account endpoint (protected)
app.post('/create-account', authenticateToken, async (req, res) => {
    const { accountNumber, balance } = req.body;

    // Basic validation
    if (!accountNumber || balance == null) {
        return res.status(400).json({ message: 'All fields are required' });
    }

    // Check if account already exists for the user
    const accountExists = await Account.findOne({ userId: req.user.id });
    if (accountExists) {
        return res.status(400).json({ message: 'User already has an account' });
    }

    // Create account
    const newAccount = new Account({ userId: req.user.id, username: req.user.username, accountNumber, balance });
    await newAccount.save();
    res.status(200).json({ message: 'Account created successfully' });
});



// Add this endpoint to your existing server.js file

// Transfer money endpoint (protected)
// Transfer money endpoint (protected)
app.post('/transfer-money', authenticateToken, async (req, res) => {
    const { fromAccountNumber, toAccountNumber, amount } = req.body;

    // Basic validation
    if (!fromAccountNumber || !toAccountNumber || amount == null) {
        return res.status(400).json({ message: 'All fields are required' });
    }

    // Find the sender's account
    const fromAccount = await Account.findOne({ accountNumber: fromAccountNumber, userId: req.user.id });
    if (!fromAccount) {
        return res.status(400).json({ message: 'Sender account not found' });
    }

    // Find the recipient's account
    const toAccount = await Account.findOne({ accountNumber: toAccountNumber });
    if (!toAccount) {
        return res.status(400).json({ message: 'Recipient account not found' });
    }

    // Check if the sender has enough balance
    if (fromAccount.balance < amount) {
        return res.status(400).json({ message: 'Insufficient balance' });
    }

    // Perform the transfer
    fromAccount.balance -= amount;
    toAccount.balance += amount;

    // Save the updated accounts
    await fromAccount.save();
    await toAccount.save();

    res.status(200).json({ message: 'Transfer successful' });
});
// Add this endpoint to your existing server.js file

// Check balance endpoint (protected)
app.get('/check-balance', authenticateToken, async (req, res) => {
    // Find the user's account
    const account = await Account.findOne({ userId: req.user.id });
    if (!account) {
        return res.status(400).json({ message: 'Account not found' });
    }

    // Return the balance
    res.status(200).json({ balance: account.balance });
});



// Update profile endpoint (protected)
// Profile update endpoint (protected)
app.post('/update-profile', authenticateToken, async (req, res) => {
    const { name, email, password } = req.body;

    console.log('Received update profile request:', req.body);

    // Basic validation
    if (!name || !email) {
        return res.status(400).json({ message: 'Name and email are required' });
    }

    try {
        // Find the user
        const user = await User.findById(req.user.id);
        if (!user) {
            return res.status(400).json({ message: 'User not found' });
        }

        // Update user information
        user.username = name;
        user.email = email;
        user.password=password;

        // Save the updated user
        await user.save();

        res.status(200).json({ message: 'Profile updated successfully' });
    } catch (error) {
        console.error('Error updating profile:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
});


// Start the server
app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});